package com.example.repository;

import com.example.model.ReviewAndRating;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReviewAndRatingRepository extends CrudRepository<ReviewAndRating,String>
{
}
