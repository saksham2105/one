package com.example.repository;

import com.example.model.Purchased;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PurchasedRepository extends CrudRepository<Purchased,Integer>
{

}
