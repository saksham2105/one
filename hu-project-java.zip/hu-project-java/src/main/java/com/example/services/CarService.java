package com.example.services;

import com.example.model.Car;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
@Service
public class CarService
{
    public Car getNewestCarWithLowestPrice(List<Car> aCars, List<Car> bCars)
    {
        return Stream.of(aCars,bCars).flatMap(x -> x.stream()).collect(Collectors.toList()).stream().sorted((c1, c2)-> c1.getPrice().compareTo(c2.getPrice())).collect(Collectors.toList()).stream().sorted((c1,c2)->c2.getYear().compareTo(c1.getYear())).collect(Collectors.toList()).get(0);

    }
    public Car getPetrolBmwWithAutoTransmissionAndHighestMileage(List<Car> bCars)
    {
        return bCars.stream().filter((c) -> c.getFuelType().equals("Petrol") && c.getTransmission().equals("Automatic")).collect(Collectors.toList()).stream().sorted((c1,c2) -> c2.getMileage().compareTo(c1.getMileage())).collect(Collectors.toList()).get(0);
    }
    public Car getDieselAudiWithManualTranmissionAndHighestMileage(List<Car> aCars)
    {
        return aCars.stream().filter((c) -> c.getFuelType().equals("Diesel") && c.getTransmission().equals("Manual")).collect(Collectors.toList()).stream().sorted((c1,c2)-> c2.getMileage().compareTo(c1.getMileage())).collect(Collectors.toList()).get(0);
    }
    public List<Car> topTenCheapestCarWith2LtrsOfEngine(List<Car> aCars,List<Car> bCars)
    {
        return Stream.of(aCars,bCars).flatMap(x -> x.stream()).collect(Collectors.toList()).stream().sorted((c1,c2)-> c1.getPrice().compareTo(c2.getPrice())).filter((c) -> c.getEngineSize()==2).limit(10).collect(Collectors.toList());

    }
    public List<Car> top5ModelCarWithMileageAbove7000(List<Car> aCars,List<Car> bCars)
    {
        return Stream.of(aCars,bCars).flatMap(x-> x.stream()).collect(Collectors.toList()).stream().sorted((c1 ,c2) -> c2.getPrice().compareTo(c1.getPrice())).collect(Collectors.toList()).stream().filter((x) -> x.getMileage()>7000).limit(5).collect(Collectors.toList());
    }

    public List<Car> getTop10PetrolCarsWithTaxAbove200(List<Car> aCars,List<Car> bCars)
    {
        return Stream.of(aCars,bCars).flatMap(x-> x.stream()).collect(Collectors.toList()).stream().sorted((c1, c2) -> c2.getTax().compareTo(c1.getTax())).collect(Collectors.toList()).stream().filter((c) -> c.getTax()>200 && c.getFuelType().equals("Petrol")).limit(10).collect(Collectors.toList());
    }
    public List<Car> top3BmwLatestModelOfTypAuto(List<Car> bCars)
    {
        return bCars.stream().sorted((c1,c2) -> c2.getYear().compareTo(c1.getYear())).collect(Collectors.toList()).stream().filter((c) -> c.getTransmission().equals("Automatic") && c.getPrice()>80000 && c.getPrice()<100000).limit(3).collect(Collectors.toList());
    }
    public List<Car> top5SemiAutoAudisWithMpgGreaterThan60(List<Car> aCars)
    {
        return aCars.stream().filter((x)-> x.getTransmission().equals("Semi-Auto") && x.getMpg()>60).limit(5).sorted((c1 , c2) -> c2.getPrice().compareTo(c1.getPrice())).collect(Collectors.toList());
    }
    public Car getCarWithManualTranmissionWithHighestPrice(List<Car> aCars,List<Car> bCars)
    {
        return Stream.of(aCars,bCars).flatMap((x) -> x.stream()).collect(Collectors.toList()).stream().sorted((c1,c2) -> c2.getPrice().compareTo(c1.getPrice())).collect(Collectors.toList()).stream().filter((c) -> c.getTransmission().equals("Manual")).limit(1).collect(Collectors.toList()).get(0);
    }
}
