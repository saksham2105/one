package com.example.services;
import com.example.model.ReviewAndRating;
import com.example.pojo.Feedback;
import com.example.repository.ReviewAndRatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
@Service
public class ReviewAndRatingService
{
@Autowired
private ReviewAndRatingRepository reviewAndRatingRepository;
@Transactional
public boolean addToRatingAndReviews(Integer userId, Integer courseId, double rating, List<String> reviews)
{
    String combinedPrimaryKey=String.valueOf(userId)+"_"+String.valueOf(courseId); //combined PK
    ReviewAndRating reviewAndRating=new ReviewAndRating();
    reviewAndRating.setId(combinedPrimaryKey);
    reviewAndRating.setRating(rating);
    reviewAndRating.setReviews(reviews);
    this.reviewAndRatingRepository.save(reviewAndRating);
    return true;
}
@Transactional
 public List<Feedback> getFeedbackForCourse(Integer courseId)
 {
  List<Feedback> feedbacks=new ArrayList<>();
  List<ReviewAndRating> reviewAndRatings=new ArrayList<>();
 this.reviewAndRatingRepository.findAll().forEach((rar)->{
     reviewAndRatings.add(rar);
 });
 for(ReviewAndRating rar : reviewAndRatings)
 {
  String[] splitted=rar.getId().split("_");
  if(splitted[1].equals(String.valueOf(courseId)))
  {
   Feedback feedback=new Feedback();
   feedback.setRating(rar.getRating());
   feedback.setReviews(rar.getReviews());
   feedbacks.add(feedback);
  }
 }
 return feedbacks;
 }

 public List<ReviewAndRating> getAllRatingsAndReviews(){
    List<ReviewAndRating> list=new ArrayList<>();
    this.reviewAndRatingRepository.findAll().forEach((rar)->{
        list.add(rar);
    });
    return list;
 }
}
