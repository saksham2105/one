package com.example.services;

import com.example.model.Course;
import com.example.model.Crud;
import com.example.model.User;
import com.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService
{
 @Autowired
 UserRepository userRepository;
 @Autowired
 CrudService crudService;
 public boolean addUser(User user)
 {
  List<User> users=new ArrayList<>();
  this.userRepository.findAll().forEach((u)->{
   users.add(u);
  });
  for(User user1 : users)
  {
   if((int)user1.getId()==(int)user.getId()) return false;
  }
  this.userRepository.save(user);
  return true;
 }
 public List<User> getAllUsers()
 {
  List<User> users=new ArrayList<>();
  this.userRepository.findAll().forEach((user)->{
   users.add(user);
  });
  return users;
 }
 public User getUserById(Integer id)
 {
  List<User> users=getAllUsers();
  for(User u : users)
  {
   if(u.getId()==id)
   {
    return u;
   }
  }
  return null;
 }
 public boolean updateUser(User user)
 {
  List<User> users=getAllUsers();
  boolean flag=false;
  for(User u : users)
  {
   if(u.getId()==user.getId())
   {
    flag=true;
   }
  }
  if(flag==true)  this.userRepository.save(user);
  return flag;
 }
 public List<Course> getCoursesAllotedToUser(Integer userId,List<Crud> cruds)
 {
  List<Course> courses=new ArrayList<>();
  List<User> users=getAllUsers();
  boolean flag=false;
  for(User u : users)
  {
   if((int)u.getId()==(int)userId)
   {
    flag=true;
   }
  }
  if(!flag) return courses;
  for(Crud c : cruds)
  {
   if((int)c.getId()==(int)userId)
   {
    courses=c.getCourses();
    break;
   }
  }
  return courses;
 }
}
