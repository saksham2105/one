package com.example.services;

import com.example.model.*;
import com.example.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
@Service
public class CartService
{
    @Autowired
    private CrudService crudService;
    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private CourseService courseService;
    @Autowired
    private UserService userService;
    @Autowired
    PurchasedService purchasedService;
    public String addToCart(Integer userid, CourseId courseId,List<Crud> cruds,List<User> users,List<Course> allCoursesMappedToUser,List<Course> courses,List<User> allUsersMapped)
    {
        boolean userExist=false;
        for(int i=0;i<allUsersMapped.size();i++)
        {
            if((int)userid==(int)allUsersMapped.get(i).getId()) userExist=true;
        }
        if(!userExist) return "Couldn't added as user doen't have any access";
        List<Course> coursesToAdd=new ArrayList<>();
        User user=null;
        for(User u : users)
        {
            if((int)userid==(int)u.getId()) user=u;
        }
        if(user==null) return "Couldn't added as user doen't exist";
        for(Course c : allCoursesMappedToUser)
        {
            for(Integer i : courseId.getCourseIds())
            {
                if((int)i==(int)c.getId())  coursesToAdd.add(c);
            }
        }
        if(courseId==null || coursesToAdd.size()==0) return "Couldn't add to cart as there is no course mapped";
        if(coursesToAdd.size()!=courseId.getCourseIds().size())
        {
            Cart cart=new Cart();
            cart.setCourses(coursesToAdd);
            cart.setId(user.getId());
            this.cartRepository.save(cart);
            return "Some courses couldn't added as they were not mapped to user";
        }
        else
        {
            Cart cart=new Cart();
            cart.setCourses(coursesToAdd);
            cart.setId(user.getId());
            this.cartRepository.save(cart);
            return "Added all courses to cart successfully for a given user";
        }
    }
    public List<Cart> getAllCarts()
    {
        List<Cart> carts=new ArrayList<>();
        this.cartRepository.findAll().forEach((c)->{
            carts.add(c);
        });
        return carts;
    }
    public Cart getCartFromUserId(Integer id)
    {
        List<Cart> carts=getAllCarts();
        List<Cart> test=new ArrayList<>();
        Cart cart=null;
        for(Cart c : carts)
        {
            if((int)c.getId()==(int)id){
                cart=c;
                test.add(c);
            };
        }
        return cart;
    }
    public boolean deleteCourseFromCart(Cart cart,Course course)
    {
        boolean flag=false;
        List<Course> courses=cart.getCourses();
        if(courses.size()==0) return false;
        for(int i=0;i<courses.size();i++)
        {
            if((int)courses.get(i).getId()==(int)course.getId()) {
                courses.remove(i);
                flag=true;
            }
        }
        cart.setCourses(courses);
        this.cartRepository.save(cart);
        return flag;
    }
    public boolean checkout(Integer userId)
    {
        Cart cart=getCartFromUserId(userId);
        if(cart==null) return false;
        if(cart.getCourses().size()==0) return false;
        this.cartRepository.delete(cart);
        return true;
    }
    public String generateReceiptFor(Integer userId,User user)
    {
        try {
            Cart cart=getCartFromUserId(userId);
            long totalPrice=0;
            if(user==null) return "User doesn't exist";
            if(user.getId()!=userId) return "User Id doesn't match";
            String FILE = "C:/Users/sakssolanki/Desktop/User_"+String.valueOf(userId)+"_"+user.getFirstName()+".pdf";
            OutputStream file = null;
            file=new FileOutputStream(new File(FILE));
            Document document = new Document();
            PdfWriter.getInstance(document, file);
            document.open();
            document.add(new Paragraph("This is the Cart Receipt For User with Id :"+String.valueOf(cart.getId()+" and name : "+user.getFirstName()+" "+user.getLastName())
            ));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("You have added following courses in the cart"));
            for(Course c : cart.getCourses())
            {
             totalPrice+=(c.getPrice()-(c.getPrice()*c.getDiscount())/100);
             document.add(new Paragraph("Course Id : "+String.valueOf(c.getId())+" , Course Name : "+c.getTitle()+" ,Course Creator : "+c.getCourse_creator()+" ,Course Price : "+c.getPrice()));
             for(String s : c.getTags())
             {
               document.add(new Paragraph("Tags : "+s));
             }
             document.add(new Paragraph("\n"));
            }
            document.add(new Paragraph("Your Total Price for Cart Items : Rs "+String.valueOf(totalPrice)+" /-"));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph(new Date(new java.util.Date().getTime()).toString()));
            document.addCreationDate();
            document.addAuthor("By Online Learning Course Platform");
            document.addTitle("Cart Receipt");
            document.close();
            return "Receipt Generated Successfully !";
        } catch (Exception e) {
            return "Some Problem";
        }


    }
}
