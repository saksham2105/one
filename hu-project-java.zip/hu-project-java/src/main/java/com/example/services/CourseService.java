package com.example.services;
import com.example.model.Course;
import com.example.pojo.CoursePojo;
import com.example.pojo.Feedback;
import com.example.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@Service
public class CourseService
{
    @Autowired
    CourseRepository courseRepository;
    @Autowired
    ReviewAndRatingService reviewAndRatingService;
    public boolean addCourse(Course course)
    {
        List<Course> courses=new ArrayList<>();
        this.courseRepository.findAll().forEach((c)->{
            courses.add(c);
        });
        for(Course c1 : courses)
        {
            if((int)c1.getId()==(int)course.getId()) return false; //check for course already exists
        }
        this.courseRepository.save(course);
        return true;
    }

    public List<Course> getAllCourses()
    {
        List<Course> courses=new ArrayList<>();
        this.courseRepository.findAll().forEach((c)->{
            courses.add(c);
        });
        return courses;
    }
    public Course getCourseById(Integer id)
    {
        List<Course> courses=getAllCourses();
        for(Course c :courses)
        {
            if((int)c.getId()==(int)id) return c;
        }
        return null;
    }
    public boolean updateCourse(Course course)
    {
        List<Course> courses=getAllCourses();
        boolean flag=false;
        for(Course c : courses)
        {
            if((int)c.getId()==(int)course.getId())
            {
                flag=true;
            }
        }
        if(flag==true)  this.courseRepository.save(course);
        return flag;
    }
    public boolean removeCourseById(Integer id) {
        List<Course> courses = getAllCourses();
        boolean flag = false;
        for (Course c : courses) {
            if((int) c.getId() == (int) id)
            {
                flag = true;
                this.courseRepository.delete(c);
            }
        }
        return flag;
    }
    public CoursePojo getAllRequiredDetailsOfACourse(Integer courseId,List<Feedback> feedbacks)
    {
        Course c=getCourseById(courseId);
        if(c==null) return null;
        List<Double> ratings=new ArrayList<>();
        List<List<String>> reviews=new ArrayList<>();
        CoursePojo coursePojo=new CoursePojo();
        if(feedbacks.size()==0) return null;
        for(Feedback f : feedbacks)
        {
            ratings.add(f.getRating());
            reviews.add(f.getReviews());
        }
        coursePojo.setId(c.getId());
        coursePojo.setTitle(c.getTitle());
        coursePojo.setTags(c.getTags());
        coursePojo.setCourse_creator(c.getCourse_creator());
        coursePojo.setPrice(c.getPrice());
        coursePojo.setDiscount(c.getDiscount());
        coursePojo.setRatings(ratings);
        coursePojo.setReviewsOfReviews(reviews);
        return coursePojo;
    }
    public List<Course> getCoursesByPageNumber(Integer pageNumber,Integer pageSize)
    {
        try{
            pageSize=(int)pageSize;
            pageNumber=(int)pageNumber;
            List<Course> allCourses=getAllCourses();
            int lastIndex=allCourses.size();
            int from=(pageNumber-1)*pageSize;
            int to=from+pageSize;
            if(from>allCourses.size()-1) return null;
            if(to>lastIndex) to=lastIndex;
            return allCourses.subList(from,to);
        }catch (Exception e)
        {
            return  null;
        }
    }

    public List<Course> getCoursesByLowerOrderOfPrice()
    {
        return getAllCourses().stream().sorted((c1,c2)->c1.getPrice().compareTo(c2.getPrice())).collect(Collectors.toList());
    }
    public List<Course> getCoursesByHigherOrderOfPrice()
    {
        return getAllCourses().stream().sorted((c1,c2)->c2.getPrice().compareTo(c1.getPrice())).collect(Collectors.toList());
    }
    public List<Course> getAllCoursesContained(String keyword)
    {
        return getAllCourses().stream().filter((c) -> c.getTitle().toLowerCase().contains(keyword.toLowerCase())).collect(Collectors.toList());
    }
}
