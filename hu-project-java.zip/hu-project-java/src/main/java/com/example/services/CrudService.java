package com.example.services;

import com.example.model.Course;
import com.example.model.CourseId;
import com.example.model.Crud;
import com.example.model.User;
import com.example.repository.MapRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Service
public class CrudService
{
    @Autowired
    MapRepository crudRepository;
    @Autowired
    UserService userService;
    @Autowired
    CourseService courseService;

    public List<Course> getAllCoursesMappedToUser(Integer userId)
    {
        List<Crud> cruds=getAllCruds();
        List<Course> courses=new ArrayList<>();
        for(Crud c : cruds)
        {
            if((int)c.getId()==(int)userId)
            {
                courses=c.getCourses();
                break;
            }
        }
        return courses;
    }

    //service to map N courses to 1 user
    @Transactional
    public String mapAllCoursesWithUser(Integer userId, CourseId courseId,List<Course> allCourses,User user)
    {
        List<Course> courses=new ArrayList<>();
        for(Course c : allCourses)
        {
            for(Integer i : courseId.getCourseIds())
            {
                if((int) c.getId()==(int) i)  courses.add(c);
            }
        }
        if(user==null) return "User doesn't exist to map";
        if(courses.size()==0) return "No courses are not either in database that has matched to course ids";
        if(courses.size()!=courseId.getCourseIds().size())
        {
            Crud crud=new Crud();
            crud.setId(user.getId());
            crud.setCourses(courses);
            this.crudRepository.save(crud);
            return "Some courses are mapped to user some couldn't mapped since they were not in database";
        }
        else
        {
            Crud crud=new Crud();
            crud.setId(user.getId());
            crud.setCourses(courses);
            this.crudRepository.save(crud);
            return "Mapped all courses to given user successfully";
        }
    }
    //service to demap N courses to 1 user
    @Transactional
    public boolean demapAllCoursesWithUser(Integer userId,User user,List<Course> courses)
    {
        if(user==null) return false;
        if(courses==null || courses.size()==0) return false;

        List<Crud> cruds=new ArrayList<>();
        this.crudRepository.findAll().forEach((cr)->{
            cruds.add(cr);
        });
        if(cruds.size()==0) return false;
        Crud crud=null;
        for(Crud c : cruds)
        {
            if((int)c.getId()==(int)userId)
            {
                crud=c;
            }
        }
        if(crud==null) return false;
        else{
            this.crudRepository.delete(crud);
            return true;
        }
    }

    @Transactional
    public List<User> getAllUsersMappedToCourses(List<User> allUsers)
    {
        List<Crud> cruds=new ArrayList<>();
        this.crudRepository.findAll().forEach((c)->{
            cruds.add(c);
        });
        List<User> usersToReturn=new LinkedList<>();
        for(Crud c : cruds)
        {
            for(User u : allUsers)
            {
                if((int)c.getId()==(int)u.getId())  usersToReturn.add(u);
            }
        }
        return usersToReturn;
    }

    @Transactional
    public List<Crud> getAllCruds()
    {
        List<Crud> cruds=new ArrayList<>();
        this.crudRepository.findAll().forEach((c)->{
            cruds.add(c);
        });
        return cruds;
    }
}
