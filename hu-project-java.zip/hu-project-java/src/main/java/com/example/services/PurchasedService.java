package com.example.services;
import com.example.model.*;
import com.example.repository.PurchasedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PurchasedService
{
    @Autowired
    PurchasedRepository purchasedRepository;
    @Autowired
    private CourseService courseService;
    @Autowired
    private UserService userService;
    @Autowired
    private CartService cartService;
    //used all the necessary checks in the below function to validate all the edges
    public boolean addToPurchasedCourses(Integer userId, CourseId courseId,List<Course> courses,List<User> users,Cart cart)
    {
        List<Course> coursesToAdd=new ArrayList<>();
        User user=null;
        for(User u : users)
        {
            if((int)userId==(int)u.getId()) user=u;
        }
        if(user==null) return false;
        for(Integer i : courseId.getCourseIds())
        {
            for(Course c : courses)
            {
                if((int)c.getId()==(int)i) coursesToAdd.add(c);
            }
        }
        if(courseId.getCourseIds().size()==0) return false;
        if(coursesToAdd.size()==0) return false;
        if(coursesToAdd.size()!=courseId.getCourseIds().size()) return false;
        Purchased purchased=new Purchased();
        purchased.setId(user.getId());
        purchased.setCourses(coursesToAdd);
        if(cart!=null) //cart can be empty for user
        {
            for(Course c1 : cart.getCourses())
            {
                for(Course c2 : purchased.getCourses())
                {
                    if((int)c1.getId()==(int)c2.getId()) this.cartService.deleteCourseFromCart(cart,c1);
                }
            }
        }
        this.purchasedRepository.save(purchased);
        return true;
    }
    public Purchased getPurchasedCoursesFromUserId(Integer userId)
    {
     List<Purchased> purchaseds=new ArrayList<>();
     Purchased purchased=null;
     this.purchasedRepository.findAll().forEach((p)->{
             purchaseds.add(p);
     });
     for(Purchased p : purchaseds)
     {
      if((int)p.getId()==(int)userId) purchased=p;
     }
     return purchased;
    }

}
