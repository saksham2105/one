package com.example.services;
import com.example.model.Popularity;
import com.example.repository.PopularityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PopularityService
{
@Autowired
PopularityRepository popularityRepository;
public String addToPopularity(Integer id,Integer rank){
    Popularity p=new Popularity();
    p.setId(id);
    p.setRank(rank);
    this.popularityRepository.save(p);
    return "Popularity Given to the course successfully";
}
public List<Popularity> getAllPopularity()
{
 List<Popularity> popularities=new ArrayList<>();
 this.popularityRepository.findAll().forEach((p)->{
     popularities.add(p);
 });
 return popularities;
}
}
