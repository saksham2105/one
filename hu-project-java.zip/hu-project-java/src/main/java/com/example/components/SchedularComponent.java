package com.example.components;

import com.example.model.Popularity;
import com.example.model.ReviewAndRating;
import com.example.services.PopularityService;
import com.example.services.ReviewAndRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.security.KeyStore;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class SchedularComponent {
    @Autowired
    ReviewAndRatingService reviewAndRatingService;
    @Autowired
    PopularityService popularityService;

    public double getAverageRatingForCourseId(String courseId,List<ReviewAndRating> list)
    {
     List<ReviewAndRating> l= list.stream().filter((x)-> x.getId().split("_")[1].equals(courseId)).collect(Collectors.toList());
     double rating=0;
     int times=1;
     for(ReviewAndRating rar : l)
     {
       rating+=rar.getRating();
       times+=1;
     }
     return rating/times;
    }
    @Scheduled(initialDelay = 2000L,fixedRate = 6000L)
    public void setPopularityRank()
    {
        List<ReviewAndRating> list=this.reviewAndRatingService.getAllRatingsAndReviews();
        HashMap<String,Double> map=new HashMap<>();
        for(ReviewAndRating rar : list)
        {
         String[] splitted=rar.getId().split("_");
         if(map.get(splitted[1])==null || map.containsKey(splitted[1])==false)
         {
           map.put(splitted[1],getAverageRatingForCourseId(splitted[1],list));
         }
        }
        List<Double> sortedRatings=new ArrayList<>();
        for (Map.Entry mapElement : map.entrySet()) {
            sortedRatings.add((double)mapElement.getValue());
        }
        sortedRatings=sortedRatings.stream().sorted((c1,c2)-> c2.compareTo(c1)).collect(Collectors.toList());
        int rank=1;
        for(Double d : sortedRatings)
        {
            for (Map.Entry mapElement : map.entrySet()) {
                if(d==(double)mapElement.getValue()){
                    String id=String.valueOf(mapElement.getKey());
                    Integer a=Integer.parseInt(id);
                    this.popularityService.addToPopularity(a,rank);
                }
            }
            rank+=1;

        }
        List<Popularity> popularities=this.popularityService.getAllPopularity();
        if(popularities.size()==0)
        {
            System.out.println("No popularity has been given to any course");
        }
        else
        {
            for(Popularity p : popularities)
            {
                System.out.println("Course Id : "+p.getId()+",Course Rank : "+p.getRank());
            }
        }
    }
}