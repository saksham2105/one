package com.example.controllers;

import com.example.model.Course;
import com.example.model.User;
import com.example.pojo.Feedback;
import com.example.services.CourseService;
import com.example.services.ReviewAndRatingService;
import com.example.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/onlineLearning/coursefeedback")
public class ReviewAndRatingController
{
@Autowired
private ReviewAndRatingService reviewAndRatingService;
@Autowired
private UserService userService;
@Autowired
private CourseService courseService;
@PostMapping("/from/{userId}/for/{courseId}")
 public String addInReviewAndRatingTable(@PathVariable Integer userId, @PathVariable Integer courseId, @RequestBody Feedback feedback)
 {
  List<User> users=this.userService.getAllUsers();
  List<Course> courses=this.courseService.getAllCourses();
  boolean flag1=false;
  boolean flag2=false;
  for(User user : users)
  {
   if((int)user.getId()==(int)userId) flag1=true;
  }
  if(!flag1) return "User Not Found against given user id";
  for(Course course : courses)
  {
   if((int)course.getId()==(int)courseId) flag2=true;
  }
  if(!flag2) return "Course Not Found against given id";
  boolean res=this.reviewAndRatingService.addToRatingAndReviews(userId,courseId,feedback.getRating(),feedback.getReviews());
  if(res) return "Review and Rating successfully added";
  else return "Some Problem";
 }
}
