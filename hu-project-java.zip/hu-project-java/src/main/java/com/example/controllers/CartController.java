package com.example.controllers;

import com.example.model.*;
import com.example.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.itextpdf.text.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/onlineLearning/cart")
public class CartController
{
 @Autowired
 CartService cartService;
 @Autowired
 CourseService courseService;
 @Autowired
 CrudService crudService;
 @Autowired
 UserService userService;
 @Autowired
 PurchasedService purchasedService;
 @PostMapping("/addToCart/{userId}")
 public String addToCart(@PathVariable Integer userId, @RequestBody CourseId courseId)
 {
  List<Crud> cruds=crudService.getAllCruds();
  List<User> users=this.userService.getAllUsers();
  List<User> allUsersMapped=this.crudService.getAllUsersMappedToCourses(users);
  List<Course> allCoursesMappedToUser=this.crudService.getAllCoursesMappedToUser(userId);
  List<Course> courses=this.courseService.getAllCourses();
  String res=cartService.addToCart(userId,courseId,cruds,users,allCoursesMappedToUser,courses,allUsersMapped);
  return res;
 }
 @GetMapping("/getCartFromUserId/{userId}")
 public Object getCartFromUserId(@PathVariable Integer userId)
 {
  Cart c=this.cartService.getCartFromUserId(userId);
  if(c==null) return "No cart exist against this user id";
  else return c;
 }
 @GetMapping("/removeCourseFromCart/{userId}/{courseId}")
 public String removeFromCart(@PathVariable Integer userId,@PathVariable Integer courseId)
 {
  Course course=this.courseService.getCourseById(courseId);
  Cart cart=this.cartService.getCartFromUserId(userId);
  boolean res=this.cartService.deleteCourseFromCart(cart,course);
  if(res) return new String("Course deleted from cart successfully");
  else return "Course can't be deleted as it is not in the cart itself";
 }
 @GetMapping("/checkout/{userId}")
 public String checkoutCart(@PathVariable Integer userId)
 {
  Cart cart=this.cartService.getCartFromUserId(userId);
  CourseId courseId=new CourseId();
  List<Integer> list=new ArrayList<>();
  for(Course c : cart.getCourses())
  {
   list.add(c.getId());
  }
  courseId.setCourseIds(list);
  boolean res=this.cartService.checkout(userId);
  if(res)
  {
   List<Course> courses=this.courseService.getAllCourses();
   List<User> users=this.userService.getAllUsers();
   Cart c=this.cartService.getCartFromUserId(userId);
   boolean res2=this.purchasedService.addToPurchasedCourses(userId,courseId,courses,users,c);
   if(res2) return "Course remove to purchased section from cart section";
   else return "Course couldn't remove to purchased section";
  }
  else return "Some Problem please check your user id or your courses in cart";
 }
 @GetMapping("/generateReceiptForMyCart/{userId}")
 public String generateReceipt(@PathVariable Integer userId)
 {
  Cart c=this.cartService.getCartFromUserId(userId);
  User user=this.userService.getUserById(userId);
  if(c==null) {
   return "No Cart exist against the given user id";
  }
  else
  {
  if(user==null)
  {
   return "User Doesn't exist";
  }
  else return this.cartService.generateReceiptFor(userId,user);
  }
 }
}
