package com.example.controllers;
import com.example.model.Car;
import com.example.services.CarService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.util.*;
@RestController
public class CarController
{
    CarService carService=new CarService();
    //list population for bmw array
    public List<Car> populateBmwCars()
    {
        List<Car> aCars=new ArrayList<>();
        try {
            Scanner sc;
            sc = new Scanner(new File("./src/main/java/com/example/assignment1/bmw.csv"));
            sc.nextLine();
            Car car;
            //populating cars array ny fetching data from csv file
            while (sc.hasNext()) {
                String[] line = sc.nextLine().split(",");
                car = new Car();
                car.setId(UUID.randomUUID().toString()); // generating random unique id
                car.setModel(line[0]);
                car.setYear(Integer.parseInt(line[1]));
                car.setPrice(Long.parseLong(line[2]));
                car.setTransmission(line[3]);
                car.setMileage(Long.parseLong(line[4]));
                car.setFuelType(line[5]);
                car.setTax(Integer.parseInt(line[6]));
                car.setMpg(Double.parseDouble(line[7]));
                car.setEngineSize(Double.parseDouble(line[8]));
                aCars.add(car);
            }
            sc.close();
            return aCars;//closes the scanner
        }catch (Exception e)
        {
            return aCars;
        }

    }

    //list population for audi array
    public List<Car> populateAudiCars()
    {
        List<Car> bCars=new ArrayList<>();
        try {
            Scanner sc;
            sc = new Scanner(new File("./src/main/java/com/example/assignment1/audi.csv"));
            sc.nextLine();
            Car car;
            //populating cars array ny fetching data from csv file
            while (sc.hasNext()) {
                String[] line = sc.nextLine().split(",");
                car = new Car();
                car.setId(UUID.randomUUID().toString()); // generating random unique id
                car.setModel(line[0]);
                car.setYear(Integer.parseInt(line[1]));
                car.setPrice(Long.parseLong(line[2]));
                car.setTransmission(line[3]);
                car.setMileage(Long.parseLong(line[4]));
                car.setFuelType(line[5]);
                car.setTax(Integer.parseInt(line[6]));
                car.setMpg(Double.parseDouble(line[7]));
                car.setEngineSize(Double.parseDouble(line[8]));
                bCars.add(car);
            }
            sc.close();
            return bCars;
        }catch (Exception e)
        {
            return bCars;
        }

    }
    @RequestMapping("/assignment1/getNewestCarWithLowestPrice")
    public Car getNewestCarWithLowestPrice()
    {
        List<Car> audiCars;
        List<Car> bmwCars;
        audiCars=populateAudiCars();
        bmwCars=populateBmwCars();
        return carService.getNewestCarWithLowestPrice(audiCars,bmwCars);
    }
    @RequestMapping("/assignment1/getPetrolBmwWithAutoTransmissionAndHighestMileage")
    public Car getPetrolBmwWithAutoTransmissionAndHighestMileage()
    {
        List<Car> bmwCars;
        bmwCars=populateBmwCars();
        return carService.getPetrolBmwWithAutoTransmissionAndHighestMileage(bmwCars);
    }
    @RequestMapping("/assignment1/getDieselAudiWithManualTranmissionAndHighestMileage")
    public Car getDieselAudiWithManualTranmissionAndHighestMileage()
    {
        List<Car> audiCars;
        audiCars=populateAudiCars();
        return carService.getDieselAudiWithManualTranmissionAndHighestMileage(audiCars);
    }
    @RequestMapping("/assignment1/topTenCheapestCarWith2LtrsOfEngine")
    public List<Car> topTenCheapestCarWith2LtrsOfEngine()
    {
        List<Car> audiCars;
        List<Car> bmwCars;
        audiCars=populateAudiCars();
        bmwCars=populateBmwCars();
        return carService.topTenCheapestCarWith2LtrsOfEngine(audiCars,bmwCars);
    }
    @RequestMapping("/assignment1/top5ModelCarWithMileageAbove7000")
    public List<Car> top5ModelCarWithMileageAbove7000()
    {
        List<Car> audiCars;
        List<Car> bmwCars;
        audiCars=populateAudiCars();
        bmwCars=populateBmwCars();
        return carService.top5ModelCarWithMileageAbove7000(audiCars,bmwCars);
    }
    @RequestMapping("/assignment1/getTop10PetrolCarsWithTaxAbove200")
    public List<Car> getTop10PetrolCarsWithTaxAbove200()
    {
        List<Car> audiCars;
        List<Car> bmwCars;
        audiCars=populateAudiCars();
        bmwCars=populateBmwCars();
        return carService.getTop10PetrolCarsWithTaxAbove200(audiCars,bmwCars);
    }
    @RequestMapping("/assignment1/top3BmwLatestModelOfTypeAuto")
    public List<Car> top3BmwLatestModelOfTypeAuto()
    {
        List<Car> bmwCars;
        bmwCars=populateBmwCars();
        return carService.top3BmwLatestModelOfTypAuto(bmwCars);
    }
    @RequestMapping("/assignment1/top5SemiAutoAudisWithMpgGreaterThan60")
    public List<Car> top5SemiAutoAudisWithMpgGreaterThan60()
    {
        List<Car> aCars;
        aCars=populateAudiCars();
        return carService.top5SemiAutoAudisWithMpgGreaterThan60(aCars);
    }
    @RequestMapping("/assignment1/getCarWithManualTranmissionWithHighestPrice")
    public Car getCarWithManualTranmissionWithHighestPrice()
    {
        List<Car> audiCars;
        List<Car> bmwCars;
        audiCars=populateAudiCars();
        bmwCars=populateBmwCars();
        return carService.getCarWithManualTranmissionWithHighestPrice(audiCars,bmwCars);
    }
}
