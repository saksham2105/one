package com.example.controllers;

import com.example.model.Course;
import com.example.model.CourseId;
import com.example.model.User;
import com.example.services.CourseService;
import com.example.services.CrudService;
import com.example.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/onlineLearning/admin")
public class CrudController
{
    @Autowired
    private CrudService crudService;
    @Autowired
    private UserService userService;
    @Autowired
    private CourseService courseService;
    @PostMapping("/mapUserToCourses/{userId}")
    public String mapUserToCourse(@PathVariable Integer userId, @RequestBody CourseId courseId)
    {
        List<Course> allCourses=this.courseService.getAllCourses();
        User user=this.userService.getUserById(userId);
        return this.crudService.mapAllCoursesWithUser(userId,courseId,allCourses,user);
    }
    @GetMapping("/demapUserToCourses/{userId}")
    public String demapUserToCourse(@PathVariable Integer userId)
    {
        User user=this.userService.getUserById(userId);
        List<Course> courses=this.crudService.getAllCoursesMappedToUser(userId);
        boolean res=this.crudService.demapAllCoursesWithUser(userId,user,courses);
        if(res) return "User with id mentioned de mapped to all courses successfully";
        else return "User couldn't de mapped with courses due to some issues";
    }
    @GetMapping("/getAllUsersMappedWithCourses")
    public Object getAllUserMappedWithCourse()
    {
        List<User> allUsers=this.userService.getAllUsers();
        List<User> users=this.crudService.getAllUsersMappedToCourses(allUsers);
        if(users.size()==0) return "No User mapped to courses";
        return users;
    }
}
