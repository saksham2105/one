package com.example.controllers;
import com.example.model.Cart;
import com.example.model.Course;
import com.example.model.Crud;
import com.example.model.User;
import com.example.services.CrudService;
import com.example.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/onlineLearning/user")
public class UserController {
 @Autowired
 UserService userService;
 @Autowired
 CrudService crudService;
 @PostMapping("/addUser")
 public String addUser(@RequestBody User user) {
  try {
   System.out.println("Add User Controller service invoked");
   boolean res = this.userService.addUser(user);
   if (!res) {
    return "User Can't added as user already exist";
   } else return "User Added";
  } catch (Exception e) {
   return "Some Exception Encountered Please try to use correct syntax regarding api";
  }
 }

 @GetMapping("/getAllUsers")
 public Object getUsers() {
  try
  {
   System.out.println("Users get service invoked");
   if(this.userService.getAllUsers().size()==0)
   {
    return "No User Exist in the database";
   }
   else return this.userService.getAllUsers();
  }catch(Exception e){
   return "Some Problem Occured";
  }
 }

 @GetMapping("/getUserById/{id}")
 public Object getUserById(@PathVariable Integer id) {
  try
  {
   User user=this.userService.getUserById(id);
   if(user!=null)
   {
    return user;
   }
  }catch(Exception e)
  {
  }
  return new String("User doesn't exist in the database");
 }
 @PostMapping("/updateUser")
 public String updateUser(@RequestBody User user)
 {
  boolean res=this.userService.updateUser(user);
  if(res) return "User Updated Successfully";
  else return "User doesn't exist in the database";
 }
 @GetMapping("/getCoursesAllotedTo/{userId}")
 public Object getCoursesAllotedTo(@PathVariable Integer userId)
 {
  List<Crud> cruds=this.crudService.getAllCruds();
  List<Course> courses=this.userService.getCoursesAllotedToUser(userId,cruds);
  if(courses.size()==0) return "No courses has been allocated to the mentioned user";
  else return courses;
 }
}