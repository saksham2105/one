package com.example.controllers;

import com.example.model.*;
import com.example.services.CartService;
import com.example.services.CourseService;
import com.example.services.PurchasedService;
import com.example.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/onlineLearning/purchased")
public class PurchasedController
{
  @Autowired
    PurchasedService purchasedService;
  @Autowired
    CourseService courseService;
  @Autowired
    UserService userService;
  @Autowired
    CartService cartService;
 @PostMapping("/addToPurchased/{userId}")
 public String addToPurchased(@PathVariable Integer userId, @RequestBody CourseId courseId)
 {
     List<Course> courses=this.courseService.getAllCourses();
     List<User> users=this.userService.getAllUsers();
     Cart cart=this.cartService.getCartFromUserId(userId);
     boolean res=purchasedService.addToPurchasedCourses(userId,courseId,courses,users,cart);
     if(res) return "Courses successfully ordered";
     else return "Course couldn't be ordered please check your manuals regarding using api";
 }
 @GetMapping("/getPurchasedCoursesFromUserId/{userId}")
 public Object getPurchasedCoursesFromUserId(@PathVariable Integer userId)
 {
   Purchased purchased=this.purchasedService.getPurchasedCoursesFromUserId(userId);
   if(purchased==null) return new String("No course has been purchased from the given user id");
   else return purchased;
 }
}
