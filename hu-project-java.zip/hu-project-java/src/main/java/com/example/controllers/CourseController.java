package com.example.controllers;

import com.example.model.Course;
import com.example.pojo.CoursePojo;
import com.example.pojo.Feedback;
import com.example.services.CourseService;
import com.example.services.ReviewAndRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/onlineLearning/course")
public class CourseController
{
    @Autowired
    CourseService courseService;
    @Autowired
    ReviewAndRatingService reviewAndRatingService;
    @PostMapping("/addCourse")
    public String addCourse(@RequestBody Course course)
    {
        boolean res=this.courseService.addCourse(course);
        if(!res)
        {
            return "Course can't be added as it already exists against some id";
        }
        else return "Course added successfully";
    }

    @GetMapping("/getAllCourses")
    public Object getAllCourses()
    {
        try
        {
            if(this.courseService.getAllCourses().size()==0)
            {
                return "No Course Exist in the database";
            }
            else return this.courseService.getAllCourses();
        }catch(Exception e){
            return "Some Problem Occured";
        }
    }

    @GetMapping("/getCourseById/{id}")
    public Object getUserById(@PathVariable Integer id) {
        try
        {
            Course course=this.courseService.getCourseById(id);
            if(course!=null)
            {
                return course;
            }
        }catch(Exception e)
        {
        }
        return new String("Course doesn't exist in the database");
    }
    @PostMapping("/updateCourse")
    public String updateCourse(@RequestBody Course course)
    {
        boolean res=this.courseService.updateCourse(course);
        if(res) return "Course Updated Successfully";
        else return "Your course doesn't exist in the database";
    }
    @GetMapping("/removeCourseById/{id}")
    public String removeCourse(@PathVariable Integer id)
    {
        boolean res=this.courseService.removeCourseById(id);
        if(!res) return new String("Can't remove course as it doesn't exist");
        else return "Course remove successfully";
    }
    @GetMapping("/getAllRequiredDetailsOfACourse/{courseId}")
    public Object getAllRequiredDetailsOfACourse(@PathVariable Integer courseId)
    {
        List<Feedback> feedbacks=this.reviewAndRatingService.getFeedbackForCourse(courseId);
        if(feedbacks==null || feedbacks.size()==0)
        {
         return "No feedbacks available for this course";
        }
        CoursePojo coursePojo=this.courseService.getAllRequiredDetailsOfACourse(courseId,feedbacks);
        if(coursePojo==null) return "None of the your haven't give any rating so far or some serious issues";
        else return coursePojo;
    }
    @GetMapping("/getCoursesByPageNumber/{pageNumber}/forPageSize/{pageSize}")
    public Object getCoursesByPageNumber(@PathVariable Integer pageNumber,@PathVariable Integer pageSize)
    {
        if(pageNumber<=0){
            return "Invalid Page Number";
        }
        List<Course> courses=this.courseService.getCoursesByPageNumber(pageNumber,pageSize);
        if(courses==null || courses.size()==0)
        {
            return "No Course exist against this page number with given page size";
        }
        else return courses;
    }
    @GetMapping("/getCoursesByLowerOrderOfPrice")
    public Object getCoursesByLowerOrderOfPrice()
    {
        List<Course> courses=this.courseService.getCoursesByLowerOrderOfPrice();
        if(courses==null || courses.size()==0)
        {
            return "No course exist in the database";
        }
        else return courses;
    }
    @GetMapping("/getCoursesByHigherOrderOfPrice")
    public Object getCoursesByHigherOrderOfPrice()
    {
        List<Course> courses=this.courseService.getCoursesByHigherOrderOfPrice();
        if(courses==null || courses.size()==0)
        {
            return "No course exist in the database";
        }
        else return courses;
    }
    @GetMapping("/getAllCoursesContained/{keyword}")
    public Object getAllCoursesContained(@PathVariable String keyword)
    {
        List<Course> courses=this.courseService.getAllCoursesContained(keyword);
        if(courses==null || courses.size()==0)
        {
            return "No course exist in the database";
        }
        else return courses;
    }
}
