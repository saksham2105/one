package com.example.pojo;

import java.util.List;

import com.example.model.Course;
import lombok.Setter;
import lombok.Getter;
@Setter @Getter
public class User {
    private Integer id;
    private String firstName;
    private String lastName;
    private String displayName;
    private String about;
    private List<String> area_of_interest;
    private String type;
    private String experience;
    private List<String> expertise;
    private String role;
    private String profilePicture;
    private List<Course> coursesPurchased;
    private List<Course> coursesInCart;
}
