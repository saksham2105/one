package com.example.pojo;
import java.util.List;
import lombok.*;
@Setter @Getter
public class CoursePojo
{
    private Integer id;
    private String title;
    private List<String> tags;
    private String course_creator;
    private Long price;
    private Long discount;
    private List<Double> ratings;
    private List<List<String>> reviewsOfReviews;
}
