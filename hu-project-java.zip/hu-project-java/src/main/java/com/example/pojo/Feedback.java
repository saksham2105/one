package com.example.pojo;
import lombok.*;
import java.util.List;
@Setter @Getter
public class Feedback
{
 private double rating;
 private List<String> reviews;
}
