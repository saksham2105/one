package com.example.model;
import javax.persistence.*;
import lombok.*;
import java.util.List;
@Entity
@Table(name="purchased_courses")
@Setter @Getter
public class Purchased
{
    @Id
    @Column(name="id")
    private Integer id;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="course2")
    private List<Course> courses;
}
