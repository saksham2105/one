package com.example.model;
import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Set;
@Entity
@Table(name = "users", catalog = "test")
@Getter @Setter
public class User
{
 @Id
 @Column(name="id")
 private Integer id;
 @Column(name="first_name")
 private  String firstName;
 @Column(name="last_name")
 private String lastName;
 @Column(name="display_name")
 private String displayName;
 @Column(name="about")
 private String about;
 @ElementCollection
 @Column(name="area_of_interests")
 private List<String> area_of_interest;
 @Column(name="type")
 private String type;
 @Column(name="experience")
 private String experience;
 @ElementCollection
 @Column(name="expertise")
 private List<String> expertise;
 @Column(name="role")
 private String role;
 @Column(name="profile_picture")
 private String profilePicture;
}
