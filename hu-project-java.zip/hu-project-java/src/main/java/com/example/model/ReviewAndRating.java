package com.example.model;
import javax.persistence.*;
import lombok.*;

import java.util.List;

@Setter @Getter
@Entity
@Table(name="reviews_and_rating")
public class ReviewAndRating
{
 @Id
 @Column(name="id")
 private String id;
 @Column(name="rating")
 private double rating;
 @ElementCollection
 @Column(name="reviews")
 List<String> reviews;
}
