package com.example.model;
import javax.persistence.*;
import com.example.model.Course;
import lombok.*;
import java.util.*;
@Entity
@Table(name="cruds",catalog = "test")
@Getter @Setter
public class Crud
{
    @Id
    @Column(name="id")
    private Integer id;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="course3")
    private List<Course> courses;
}