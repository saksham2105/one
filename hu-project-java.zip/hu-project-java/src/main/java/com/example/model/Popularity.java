package com.example.model;

import javax.persistence.*;
import lombok.*;
@Setter @Getter
@Entity
@Table(name="popularity" ,catalog = "test")
public class Popularity
{
    @Id
    @Column(name="id")
    private Integer id;
    @Column(name="rank")
    private Integer rank;
}
