package com.example.model;
import javax.persistence.*;
import lombok.*;
import java.util.List;
@Entity
@Table(name="course",catalog = "test")
@Setter @Getter
public class Course
{
@Id
@Column(name="id")
private Integer id;
@Column(name="title")
private String title;
@ElementCollection
@Column(name="tags")
List<String> tags;
@Column(name="course_creator")
private String course_creator;
@Column(name="price")
private Long price;
@Column(name="discount")
private Long discount;
}
