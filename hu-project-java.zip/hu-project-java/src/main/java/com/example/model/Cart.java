package com.example.model;
import javax.persistence.*;
import lombok.*;
import java.util.*;
@Entity
@Table(name="carts",catalog = "test")
@Getter @Setter
public class Cart
{
    @Id
    @Column(name="id")
    private Integer id;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="course1")
    private List<Course> courses;
}