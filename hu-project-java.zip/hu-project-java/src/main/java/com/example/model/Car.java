package com.example.model;
import lombok.*;
@Setter @Getter
public class Car
{
    private String id;
    private String model;
    private Integer year;
    private Long price;
    private String transmission;
    private Long mileage;
    private String fuelType;
    private Integer tax;
    private Double mpg;
    private Double engineSize;

}

