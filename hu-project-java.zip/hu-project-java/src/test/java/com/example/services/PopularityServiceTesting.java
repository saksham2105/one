package com.example.services;
import com.example.model.Popularity;
import com.example.repository.PopularityRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class PopularityServiceTesting
{
 @Mock
 PopularityRepository popularityRepository;
 @Autowired
 @InjectMocks
 PopularityService popularityService;
    public List<Popularity> getDummyPopularities()
    {
        List<Popularity> popularities=new ArrayList<>();
        Popularity p=new Popularity();
        p.setId(1001);
        p.setRank(1);
        popularities.add(p);
        p=new Popularity();
        p.setId(1002);
        p.setRank(2);
        popularities.add(p);
        p=new Popularity();
        p.setId(1003);
        p.setRank(3);
        popularities.add(p);
        return popularities;
    }
 @BeforeEach
 public void initSetup()
 {
 assertNotNull(popularityRepository);
 assertNotNull(popularityService);
 }

 @Test
 public void test1ForGetAllPopularity()
 {
  List<Popularity> popularities=getDummyPopularities();
  Mockito.when(this.popularityRepository.findAll()).thenReturn(popularities);
  assertTrue(this.popularityService.getAllPopularity().size()==3);
 }
    @Test
    public void test2ForGetAllPopularity()
    {
        Mockito.when(this.popularityRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(this.popularityService.getAllPopularity().size()==0);
    }
    @Test
    public void test3ForGetAllPopularity()
    {
        Mockito.when(this.popularityRepository.findAll()).thenReturn(null);
        Mockito.when(this.popularityRepository.findAll()).thenThrow(NullPointerException.class);
    }
    @Test
    public void test1ForAddToPopularity()
    {
       Popularity p= getDummyPopularities().get(0);
      Mockito.when(this.popularityRepository.save(p)).thenReturn(p);
      assertEquals(this.popularityService.addToPopularity(1001,1),"Popularity Given to the course successfully");
    }
    @Test
    public void test2ForAddToPopularity()
    {
        Popularity p= getDummyPopularities().get(0);
        Mockito.when(this.popularityRepository.save(p)).thenReturn(p);
        assertEquals(this.popularityService.addToPopularity(1002,1),"Popularity Given to the course successfully");
    }

}
