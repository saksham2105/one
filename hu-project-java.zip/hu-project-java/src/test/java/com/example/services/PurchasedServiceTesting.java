package com.example.services;
import com.example.model.*;
import com.example.repository.PurchasedRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class PurchasedServiceTesting
{
  @Mock
  PurchasedRepository purchasedRepository;
  @Mock
  CartService cartService;
  @Autowired
  @InjectMocks
  PurchasedService purchasedService;
  @BeforeEach
  public void setup()
  {
   assertNotNull(purchasedRepository);
   assertNotNull(purchasedService);
  }
  public Purchased getDummyPurchased()
  {
   Purchased purchased=new Purchased();
   purchased.setId(101);
   List<Course> courses=new ArrayList<>();
   Course c=new Course();
   c.setId(1001);
   c.setTitle("Whatever");
   courses.add(c);
   c=new Course();
   c.setId(1002);
   c.setTitle("Whatever");
   courses.add(c);
   purchased.setCourses(courses);
   return purchased;
  }
 @Test
 public void test1ForGetPurchasedCoursesFromUserId()
 {
     Purchased purchased=getDummyPurchased();
     Mockito.when(purchasedRepository.findAll()).thenReturn(Stream.of(purchased).collect(Collectors.toList()));
     assertNull(this.purchasedService.getPurchasedCoursesFromUserId(102));
 }
    @Test
    public void test2ForGetPurchasedCoursesFromUserId()
    {
        Mockito.when(purchasedRepository.findAll()).thenReturn(new ArrayList<>());
        assertNull(this.purchasedService.getPurchasedCoursesFromUserId(101));
    }
    @Test
    public void test3ForGetPurchasedCoursesFromUserId()
    {
        Purchased purchased=getDummyPurchased();
        Mockito.when(purchasedRepository.findAll()).thenReturn(Stream.of(purchased).collect(Collectors.toList()));
        assertNotNull(this.purchasedService.getPurchasedCoursesFromUserId(101));
        assertTrue(this.purchasedService.getPurchasedCoursesFromUserId(101) instanceof Purchased);
    }
    @Test
    public void test1ForAddToPurchasedCourses()
    {
        Purchased purchased=getDummyPurchased();
        Mockito.when(purchasedRepository.findAll()).thenReturn(Stream.of(purchased).collect(Collectors.toList()));
        CourseId courseId=new CourseId();
        courseId.setCourseIds(new ArrayList<>(Arrays.asList(1001,1002,1003)));
        List<User> users=new ArrayList<>();
        User user=new User();
        user.setId(101);
        users.add(user);
        user=new User();
        user.setId(102);
        users.add(user);
        assertFalse(this.purchasedService.addToPurchasedCourses(103,courseId,purchased.getCourses(),users,new Cart()));
    }
    @Test
    public void test2ForAddToPurchasedCourses()
    {
        Purchased purchased=getDummyPurchased();
        Mockito.when(purchasedRepository.findAll()).thenReturn(Stream.of(purchased).collect(Collectors.toList()));
        CourseId courseId=new CourseId();
        courseId.setCourseIds(new ArrayList<>());
        List<User> users=new ArrayList<>();
        User user=new User();
        user.setId(101);
        users.add(user);
        user=new User();
        user.setId(102);
        users.add(user);
        assertFalse(this.purchasedService.addToPurchasedCourses(101,courseId,purchased.getCourses(),users,new Cart()));
    }
    @Test
    public void test3ForAddToPurchasedCourses()
    {
        Purchased purchased=getDummyPurchased();
        Mockito.when(purchasedRepository.findAll()).thenReturn(Stream.of(purchased).collect(Collectors.toList()));
        CourseId courseId=new CourseId();
        courseId.setCourseIds(new ArrayList<>(Arrays.asList(1001,1002,1003)));
        List<Course> courses=new ArrayList<>();
        Course c=new Course();
        c.setId(1000);
        c.setTitle("Whatever");
        courses.add(c);
        c=new Course();
        c.setId(1004);
        c.setTitle("Whatever");
        courses.add(c);
        List<User> users=new ArrayList<>();
        User user=new User();
        user.setId(101);
        users.add(user);
        user=new User();
        user.setId(102);
        users.add(user);
        assertFalse(this.purchasedService.addToPurchasedCourses(101,courseId,courses,users,new Cart()));
    }
    @Test
    public void test4ForAddToPurchasedCourses()
    {
        Purchased purchased=getDummyPurchased();
        Mockito.when(purchasedRepository.findAll()).thenReturn(Stream.of(purchased).collect(Collectors.toList()));
        CourseId courseId=new CourseId();
        courseId.setCourseIds(new ArrayList<>(Arrays.asList(1001,1002,1003)));
        List<Course> courses=new ArrayList<>();
        Course c=new Course();
        c.setId(1001);
        c.setTitle("Whatever");
        courses.add(c);
        c=new Course();
        c.setId(1004);
        c.setTitle("Whatever");
        courses.add(c);
        List<User> users=new ArrayList<>();
        User user=new User();
        user.setId(101);
        users.add(user);
        user=new User();
        user.setId(102);
        users.add(user);
        assertFalse(this.purchasedService.addToPurchasedCourses(101,courseId,courses,users,new Cart()));
    }
    @Test
    public void test5ForAddToPurchasedCourses()
    {
        Purchased purchased=getDummyPurchased();
        Mockito.when(purchasedRepository.findAll()).thenReturn(Stream.of(purchased).collect(Collectors.toList()));
        CourseId courseId=new CourseId();
        courseId.setCourseIds(new ArrayList<>(Arrays.asList(1001,1002,1003)));
        List<Course> courses=new ArrayList<>();
        Course c=new Course();
        c.setId(1001);
        c.setTitle("Whatever");
        courses.add(c);
        c=new Course();
        c.setId(1002);
        c.setTitle("Whatever");
        courses.add(c);
        c=new Course();
        c.setId(1003);
        c.setTitle("Whatever");
        courses.add(c);
        List<User> users=new ArrayList<>();
        User user=new User();
        user.setId(101);
        users.add(user);
        user=new User();
        user.setId(102);
        users.add(user);
        Cart cart=new Cart();
        cart.setId(101);
        cart.setCourses(courses);
        Mockito.when(cartService.deleteCourseFromCart(cart,courses.get(0))).thenReturn(true);
        assertTrue(this.purchasedService.addToPurchasedCourses(101,courseId,courses,users,cart));
    }

}
