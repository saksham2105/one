package com.example.services;
import com.example.model.*;
import com.example.repository.CartRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class CartServiceTesting
{
 @Mock
 CartRepository cartRepository;
 @Autowired
 @InjectMocks CartService cartService;
 @BeforeEach
 public void setup(){
     assertNotNull(cartRepository);
     assertNotNull(cartService);
 }
 public Cart getDummyCart()
 {
  Cart cart=new Cart();
  cart.setId(101);
  List<Course> courses=new ArrayList<>();
  Course course=new Course();
  course.setId(1001);
  course.setTitle("React");
  course.setCourse_creator("Dr Chuck");
  course.setPrice(2000L);
  course.setDiscount(10L);
  course.setTags(new ArrayList<>(Arrays.asList("React","React")));
  courses.add(course);
  course=new Course();
  course.setId(1002);
  course.setTitle("JS");
  course.setCourse_creator("Akshay Saini");
  course.setPrice(1000L);
  course.setDiscount(5L);
  course.setTags(new ArrayList<>(Arrays.asList("JS","javaScript")));
  courses.add(course);
  cart.setCourses(courses);
  return cart;
 }
 @Test
 public void test1ForGetAllCarts()
 {
  Cart cart=getDummyCart();
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
  assertTrue(this.cartService.getAllCarts().size()==1);
 }
 @Test
 public void test2ForGetAllCarts2()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<Cart>());
  assertTrue(this.cartService.getAllCarts().size()==0);
 }
 @Test
 public void test1ForAddToCart()
 {
  Cart cart=getDummyCart();
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<>());
  assertEquals(this.cartService.addToCart(cart.getId(),new CourseId(),new ArrayList<Crud>(),new ArrayList<User>(),new ArrayList<Course>(),new ArrayList<Course>(),new ArrayList<User>()),"Couldn't added as user doen't have any access");
 }
 @Test
 public void test2ForAddToCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<>());
  List<User> allUsersMapped=new ArrayList<>();
  User user=new User();
  user.setId(101);
  allUsersMapped.add(user);
  assertEquals(this.cartService.addToCart(1001,new CourseId(),new ArrayList<Crud>(),new ArrayList<User>(),new ArrayList<Course>(),new ArrayList<Course>(),allUsersMapped),"Couldn't added as user doen't have any access");
 }
 @Test
 public void test3ForAddToCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<>());
  List<User> allUsersMapped=new ArrayList<>();
  User user1=new User();
  user1.setId(101);
  allUsersMapped.add(user1);
  List<User> users=new ArrayList<>();
  User user=new User();
  user.setId(102);
  users.add(user);
  assertEquals(this.cartService.addToCart(101,new CourseId(),new ArrayList<Crud>(),users,new ArrayList<Course>(),new ArrayList<Course>(),allUsersMapped),"Couldn't added as user doen't exist");
 }
 @Test
 public void test4ForAddToCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<>());
  List<User> allUsersMapped=new ArrayList<>();
  User user1=new User();
  user1.setId(101);
  allUsersMapped.add(user1);
  List<User> users=new ArrayList<>();
  User user=new User();
  user.setId(101);
  users.add(user);
  assertEquals(this.cartService.addToCart(101,new CourseId(),new ArrayList<Crud>(),users,new ArrayList<Course>(),new ArrayList<Course>(),allUsersMapped),"Couldn't add to cart as there is no course mapped");
 }
 @Test
 public void test5ForAddToCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<>());
  List<User> allUsersMapped=new ArrayList<>();
  User user1=new User();
  user1.setId(101);
  allUsersMapped.add(user1);
  List<User> users=new ArrayList<>();
  User user=new User();
  user.setId(101);
  users.add(user);
  CourseId courseId=new CourseId();
  courseId.setCourseIds(new ArrayList<Integer>());
  assertEquals(this.cartService.addToCart(101,courseId,new ArrayList<Crud>(),users,new ArrayList<Course>(),new ArrayList<Course>(),allUsersMapped),"Couldn't add to cart as there is no course mapped");
 }
 @Test
 public void test6ForAddToCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<>());
  List<User> allUsersMapped=new ArrayList<>();
  User user1=new User();
  user1.setId(101);
  allUsersMapped.add(user1);
  List<User> users=new ArrayList<>();
  User user=new User();
  user.setId(101);
  users.add(user);
  CourseId courseId=new CourseId();
  courseId.setCourseIds(new ArrayList<Integer>(
          Arrays.asList(1001,1002,1003)
  ));
  List<Course> allCoursesMappedToUser=new ArrayList<>();
  Course c=new Course();
  c.setId(1001);
  c.setTitle("Sasas");
  allCoursesMappedToUser.add(c);
  c=new Course();
  c.setId(1002);
  c.setTitle("Sasaasasdfdf");
  allCoursesMappedToUser.add(c);
  assertEquals(this.cartService.addToCart(101,courseId,new ArrayList<Crud>(),users,allCoursesMappedToUser,new ArrayList<Course>(),allUsersMapped),"Some courses couldn't added as they were not mapped to user");
 }
 @Test
 public void test7ForAddToCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(getDummyCart()).collect(Collectors.toList()));
  List<User> allUsersMapped=new ArrayList<>();
  User user1=new User();
  user1.setId(101);
  allUsersMapped.add(user1);
  List<User> users=new ArrayList<>();
  User user=new User();
  user.setId(101);
  users.add(user);
  CourseId courseId=new CourseId();
  courseId.setCourseIds(new ArrayList<Integer>(
          Arrays.asList(1001,1002,1003)
  ));
  List<Course> allCoursesMappedToUser=new ArrayList<>();
  Course c=new Course();
  c.setId(1001);
  c.setTitle("Sasas");
  allCoursesMappedToUser.add(c);
  c=new Course();
  c.setId(1002);
  c.setTitle("Sasaasasdfdf");
  allCoursesMappedToUser.add(c);
  c=new Course();
  c.setId(1003);
  c.setTitle("Sasaasasdfdf");
  allCoursesMappedToUser.add(c);
  assertEquals(this.cartService.addToCart(101,courseId,new ArrayList<Crud>(),users,allCoursesMappedToUser,new ArrayList<Course>(),allUsersMapped),"Added all courses to cart successfully for a given user");
 }

 @Test
 public void test1ForDeleteCourseFromCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(getDummyCart()).collect(Collectors.toList()));
  Cart cart=getDummyCart();
  Course c=new Course();
  c.setId(1001);
  c.setTitle("React");
  assertTrue(this.cartService.deleteCourseFromCart(cart,c));

 }
 @Test
 public void test2ForDeleteCourseFromCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(getDummyCart()).collect(Collectors.toList()));
  Cart cart=getDummyCart();
  Course c=new Course();
  c.setId(1003);
  c.setTitle("React");
  assertFalse(this.cartService.deleteCourseFromCart(cart,c));

 }
 @Test
 public void test3ForDeleteCourseFromCart()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(getDummyCart()).collect(Collectors.toList()));
  Cart cart=new Cart();
  cart.setId(101);
  cart.setCourses(new ArrayList<>());
  Course c=new Course();
  c.setId(1003);
  c.setTitle("React");
  assertFalse(this.cartService.deleteCourseFromCart(cart,c));

 }
 @Test
 public void test1ForCheckout()
 {
  Cart cart=getDummyCart();
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
  assertFalse(this.cartService.checkout(102));
 }
 @Test
 public void test2ForCheckout()
 {
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<>());
  assertFalse(this.cartService.checkout(101));
 }
 @Test
 public void test3ForCheckout()
 {
  Cart cart=getDummyCart();
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
  assertTrue(this.cartService.checkout(101));
  Mockito.verify(cartRepository,Mockito.times(1)).delete(cart);
 }
 @Test
 public void test1ForGetCartFromUserId(){
  Cart cart=getDummyCart();
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
  assertEquals(this.cartService.getCartFromUserId(cart.getId()).getCourses().get(0).getTitle(),"React");
 }
 @Test
 public void test2ForGetCartFromUserId(){
  Cart cart=getDummyCart();
  Mockito.when(cartRepository.findAll()).thenReturn(new ArrayList<>());
  assertNull(this.cartService.getCartFromUserId(101));
 }
 @Test
 public void test3ForGetCartFromUserId(){
  Cart cart=getDummyCart();
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
  assertNull(this.cartService.getCartFromUserId(102));
 }
 @Test
 public void test1ForGenerateReceiptFor()
 {
  Cart cart=getDummyCart();
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
  assertEquals(this.cartService.generateReceiptFor(101,null),"User doesn't exist");
 }
 @Test
 public void test2ForGenerateReceiptFor()
 {
  Cart cart=getDummyCart();
  User user=new User();
  user.setId(102);
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
  assertEquals(this.cartService.generateReceiptFor(101,user),"User Id doesn't match");
 }
 @Test
 public void test3ForGenerateReceiptFor()
 {
   Cart cart=new Cart();
   cart.setId(101);
   User user=new User();
   user.setId(101);
   Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
   assertEquals(this.cartService.generateReceiptFor(cart.getId(),user),"Some Problem");
  //exception occur due to missing details
 }
 @Test
 public void test4ForGenerateReceipt()
 {
  Cart cart=getDummyCart();
  User user=new User();
  user.setId(101);
  user.setFirstName("Saksham");
  user.setLastName("Solanki");
  user.setDisplayName("Iron Man");
  user.setExperience("0-3Years");
  user.setAbout("Whatever");
  Mockito.when(cartRepository.findAll()).thenReturn(Stream.of(cart).collect(Collectors.toList()));
  assertEquals(this.cartService.generateReceiptFor(cart.getId(),user),"Receipt Generated Successfully !");
 }
}
