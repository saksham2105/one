package com.example.services;
import com.example.model.Course;
import com.example.model.CourseId;
import com.example.model.Crud;
import com.example.model.User;
import com.example.repository.MapRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class CrudServiceTesting
{
 @Mock
 MapRepository mapRepository;
 @Autowired
 @InjectMocks
 CrudService crudService;
 @BeforeEach
 public void setup()
 {
  assertNotNull(mapRepository);
  assertNotNull(crudService);
 }
 public Crud getDummyCrud()
 {
  Crud crud=new Crud();
  crud.setId(101);
  List<Course> courses=new ArrayList<>();
  Course course=new Course();
  course.setId(1001);
  course.setTitle("Whatever");
  courses.add(course);
  course=new Course();
  course.setId(1002);
  course.setTitle("Whatever");
  courses.add(course);
  crud.setCourses(courses);
  return crud;
 }
   public List<Crud> getDummyCrudList()
   {
       List<Crud> cruds=new ArrayList<>();
        Crud crud=new Crud();
        crud.setId(101);
        List<Course> courses=new ArrayList<>();
        Course course=new Course();
        course.setId(1001);
        course.setTitle("Whatever");
        courses.add(course);
        course=new Course();
        course.setId(1002);
        course.setTitle("Whatever");
        courses.add(course);
        crud.setCourses(courses);
        cruds.add(crud);
       crud=new Crud();
       crud.setId(102);
       courses=new ArrayList<>();
       course=new Course();
       course.setId(1002);
       course.setTitle("Whatever");
       courses.add(course);
       course=new Course();
       course.setId(1003);
       course.setTitle("Whatever");
       courses.add(course);
       crud.setCourses(courses);
       cruds.add(crud);
       crud.setId(103);
       crud.setCourses(new ArrayList<>());
       return cruds;
    }
    @Test
    public void test1ForForGetAllCruds()
   {
  Crud crud=getDummyCrud();
  Mockito.when(this.mapRepository.findAll()).thenReturn(Stream.of(crud).collect(Collectors.toList()));
  assertTrue(this.crudService.getAllCruds().size()==1);
 }
  @Test
  public void test2ForForGetAllCruds()
  {
      Crud crud=getDummyCrud();
      Mockito.when(this.mapRepository.findAll()).thenReturn(new ArrayList<>());
      assertTrue(this.crudService.getAllCruds().size()==0);
    }
    @Test
    public void test3ForForGetAllCruds()
    {
        Crud crud=getDummyCrud();
        Mockito.when(this.mapRepository.findAll()).thenReturn(null);
        Mockito.when(this.mapRepository.findAll()).thenThrow(NullPointerException.class);
    }
    @Test
    public void test1ForGetAllUsersMappedToCourses()
    {
       List<Crud> cruds=getDummyCrudList();
      Mockito.when(this.mapRepository.findAll()).thenReturn(cruds);
      List<User> users=new ArrayList<>();
      User user=new User();
      user.setId(101);
      users.add(user);
      user=new User();
      user.setId(102);
      users.add(user);
      user=new User();
      user.setId(103);
      users.add(user);
      assertTrue(this.crudService.getAllUsersMappedToCourses(users).size()==2);

    }

    @Test
    public void test2ForGetAllUsersMappedToCourses()
    {
        List<Crud> cruds=getDummyCrudList();
        Mockito.when(this.mapRepository.findAll()).thenReturn(cruds);
        assertTrue(this.crudService.getAllUsersMappedToCourses(new ArrayList<>()).size()==0);

    }
    @Test
    public void test3ForGetAllUsersMappedToCourses()
    {
        Mockito.when(this.mapRepository.findAll()).thenReturn(new ArrayList<>());
        List<User> users=new ArrayList<>();
        User user=new User();
        user.setId(101);
        users.add(user);
        user=new User();
        user.setId(102);
        users.add(user);
        user=new User();
        user.setId(103);
        users.add(user);
        assertTrue(this.crudService.getAllUsersMappedToCourses(users).size()==0);

    }
    @Test
    public void test1ForGetAllCoursesMappedToUser()
    {
        List<Crud> cruds=getDummyCrudList();
        Mockito.when(this.mapRepository.findAll()).thenReturn(cruds);
        assertTrue(this.crudService.getAllCoursesMappedToUser(101).size()==2);
    }
    @Test
    public void test2ForGetAllCoursesMappedToUser()
    {
        List<Crud> cruds=getDummyCrudList();
        Mockito.when(this.mapRepository.findAll()).thenReturn(cruds);
        assertTrue(this.crudService.getAllCoursesMappedToUser(104).size()==0);
    }
    @Test
    public void test3ForGetAllCoursesMappedToUser()
    {
        Mockito.when(this.mapRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(this.crudService.getAllCoursesMappedToUser(102).size()==0);
    }
    @Test
    public void test1ForMapAllCoursesWithUser()
    {
      Crud crud=getDummyCrud();
      Mockito.when(this.mapRepository.save(crud)).thenReturn(crud);
      assertEquals(this.crudService.mapAllCoursesWithUser(101,new CourseId(),new ArrayList<Course>(),null),"User doesn't exist to map");
    }
    @Test
    public void test2ForMapAllCoursesWithUser()
    {
        Crud crud=getDummyCrud();
        Mockito.when(this.mapRepository.save(crud)).thenReturn(crud);
        CourseId courseId=new CourseId();
        courseId.setCourseIds(new ArrayList<>(Arrays.asList(1001,1002,1003)));
        List<Course> allCourses=new ArrayList<>();
        Course c=new Course();
        c.setId(1000);
        allCourses.add(c);
        c=new Course();
        c.setId(1004);
        allCourses.add(c);
        User user=new User();
        user.setId(101);
        user.setFirstName("Saksham");
        assertEquals(this.crudService.mapAllCoursesWithUser(101,courseId,allCourses,user),"No courses are not either in database that has matched to course ids");
    }
    @Test
    public void test3ForMapAllCoursesWithUser()
    {
        Crud crud=getDummyCrud();
        Mockito.when(this.mapRepository.save(crud)).thenReturn(crud);
        CourseId courseId=new CourseId();
        courseId.setCourseIds(new ArrayList<>(Arrays.asList(1001,1002,1003)));
        List<Course> allCourses=new ArrayList<>();
        Course c=new Course();
        c.setId(1001);
        allCourses.add(c);
        c=new Course();
        c.setId(1003);
        allCourses.add(c);
        User user=new User();
        user.setId(101);
        user.setFirstName("Saksham");
        assertEquals(this.crudService.mapAllCoursesWithUser(101,courseId,allCourses,user),"Some courses are mapped to user some couldn't mapped since they were not in database");
    }
    @Test
    public void test4ForMapAllCoursesWithUser()
    {
        Crud crud=getDummyCrud();
        Mockito.when(this.mapRepository.save(crud)).thenReturn(crud);
        CourseId courseId=new CourseId();
        courseId.setCourseIds(new ArrayList<>(Arrays.asList(1001,1002,1003)));
        List<Course> allCourses=new ArrayList<>();
        Course c=new Course();
        c.setId(1001);
        allCourses.add(c);
        c=new Course();
        c.setId(1002);
        allCourses.add(c);
        c=new Course();
        c.setId(1003);
        allCourses.add(c);
        User user=new User();
        user.setId(101);
        user.setFirstName("Saksham");
        assertEquals(this.crudService.mapAllCoursesWithUser(101,courseId,allCourses,user),"Mapped all courses to given user successfully");
    }
    @Test
    public void test1ForDemapAllCoursesWithUser()
    {
        Mockito.when(this.mapRepository.findAll()).thenReturn(getDummyCrudList());
        assertFalse(this.crudService.demapAllCoursesWithUser(101,null,getDummyCrud().getCourses()));
    }
    @Test
    public void test2ForDemapAllCoursesWithUser()
    {
        Mockito.when(this.mapRepository.findAll()).thenReturn(getDummyCrudList());
        assertFalse(this.crudService.demapAllCoursesWithUser(104,new User(),new ArrayList<>()));
    }
    @Test
    public void test3ForDemapAllCoursesWithUser()
    {
        Mockito.when(this.mapRepository.findAll()).thenReturn(new ArrayList<>());
        assertFalse(this.crudService.demapAllCoursesWithUser(101,new User(),getDummyCrud().getCourses()));
    }

    @Test
    public void test4ForDemapAllCoursesWithUser()
    {
        Mockito.when(this.mapRepository.findAll()).thenReturn(getDummyCrudList());
        assertFalse(this.crudService.demapAllCoursesWithUser(104,new User(),getDummyCrud().getCourses()));
    }
    @Test
    public void test5ForDemapAllCoursesWithUser()
    {
        User user=new User();
        user.setId(101);
        Mockito.when(this.mapRepository.findAll()).thenReturn(getDummyCrudList());
        assertTrue(this.crudService.demapAllCoursesWithUser(101,user,getDummyCrudList().get(0).getCourses()));
    }

}
