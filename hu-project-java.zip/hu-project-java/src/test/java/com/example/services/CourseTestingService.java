package com.example.services;
import com.example.model.Course;
import com.example.pojo.CoursePojo;
import com.example.pojo.Feedback;
import com.example.repository.CourseRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class CourseTestingService {
    @Mock
    CourseRepository courseRepository;
    @Autowired
    @InjectMocks
    CourseService courseService;

    @BeforeEach
    public void setup() {
        assertNotNull(courseRepository);
        assertNotNull(courseService);
    }

    public Course getDummyCourse() {
        Course course = new Course();
        course.setId(1001);
        course.setTitle("React");
        course.setCourse_creator("Dr Chuck");
        course.setPrice(2000L);
        course.setDiscount(10L);
        course.setTags(new ArrayList<>(Arrays.asList("React", "React")));
        return course;
    }
    public List<Course> getDummyCourseList()
    {
        List<Course> courses=new ArrayList<>();
        for(int i=1000;i<1025;i++)
        {
            Course course = new Course();
            course.setId(i);
            course.setTitle("React "+String.valueOf(i));
            course.setCourse_creator("Dr Chuck");
            course.setPrice((long)i);
            course.setDiscount(10L);
            course.setTags(new ArrayList<>(Arrays.asList("React", "React")));
            courses.add(course);
        }
        return courses;
    }

    @Test
    public void test1ForGetAllCourses() {
        Course course = getDummyCourse();
        Mockito.when(courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertTrue(this.courseService.getAllCourses().size() == 1);
    }

    @Test
    public void test2ForGetAllCourses() {
        Course course = getDummyCourse();
        Mockito.when(courseRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(this.courseService.getAllCourses().size() == 0);
    }

    @Test
    public void test1ForGetCourseById() {
        Course course = getDummyCourse();
        Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertNotNull(this.courseService.getCourseById(1001));
        assertEquals(this.courseService.getCourseById(1001).getTitle(), "React");
    }

    @Test
    public void test2ForGetCourseById() {
        Course course = getDummyCourse();
        Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertNotNull(this.courseService.getCourseById(1001));
        //assertEquals(this.courseService.getCourseById(1001).getTitle(),"React");

    }

    @Test
    public void test1ForAddCourse() {
        Course course = getDummyCourse();
        Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertFalse(this.courseService.addCourse(course));
    }

    @Test
    public void test2ForAddCourse() {
        Course course2 = new Course();
        course2.setId(1002);
        course2.setTitle("React");
        course2.setCourse_creator("Dr Chuck");
        course2.setPrice(2000L);
        course2.setDiscount(10L);
        course2.setTags(new ArrayList<>(Arrays.asList("React", "React")));
        Mockito.when(this.courseRepository.save(course2)).thenReturn(course2);
        assertTrue(this.courseService.addCourse(course2));
        Mockito.verify(courseRepository, Mockito.times(1)).save(course2);

    }
    @Test
    public void test1ForUpdateCourse()
    {
     Course course=getDummyCourse();
     Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
     assertTrue(this.courseService.updateCourse(course));
    }
    @Test
    public void test2ForUpdateCourse()
    {
        Course course=getDummyCourse();
        Course course2 = new Course();
        course2.setId(1002);
        course2.setTitle("React");
        course2.setCourse_creator("Dr Chuck");
        course2.setPrice(2000L);
        course2.setDiscount(10L);
        course2.setTags(new ArrayList<>(Arrays.asList("React", "React")));
        Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertFalse(this.courseService.updateCourse(course2));
        Mockito.when(this.courseRepository.save(course2)).thenReturn(course2);
    }
    @Test
    public void test1ForRemoveCourseById()
    {
        Course course=getDummyCourse();
        Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertFalse(this.courseService.removeCourseById(1002));
    }
    @Test
    public void test2ForRemoveCourseById()
    {
        Course course=getDummyCourse();
        Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertTrue(this.courseService.removeCourseById(1001));
        Mockito.verify(this.courseRepository,Mockito.times(1)).delete(course);
    }
    @Test
    public void test1ForGetAllRequiredDetailsOfACourse()
    {
        Course course=getDummyCourse();
        Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertNull(this.courseService.getAllRequiredDetailsOfACourse(1002,new ArrayList<Feedback>()));
    }
    @Test
    public void test2ForGetAllRequiredDetailsOfACourse()
    {
        Course course=getDummyCourse();
        Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
        assertNull(this.courseService.getAllRequiredDetailsOfACourse(1001,new ArrayList<Feedback>()));
    }
    @Test
    public void test3ForGetAllRequiredDetailsOfACourse()
    {
       List<Feedback> feedbacks=new ArrayList<>();
      Feedback feedback=new Feedback();
      feedback.setRating(4.0);
      feedback.setReviews(new ArrayList<>(Arrays.asList("Good","Better","Best")));
      feedbacks.add(feedback);
      feedback=new Feedback();
      feedback.setRating(3.0);
      feedback.setReviews(new ArrayList<>(Arrays.asList("Good","Better","Best")));
      feedbacks.add(feedback);
      Course course=getDummyCourse();
      Mockito.when(this.courseRepository.findAll()).thenReturn(Stream.of(course).collect(Collectors.toList()));
      assertNotNull(this.courseService.getAllRequiredDetailsOfACourse(1001,feedbacks));
      assertTrue(this.courseService.getAllRequiredDetailsOfACourse(1001,feedbacks) instanceof CoursePojo);
    }
    @Test
    public void test1ForGetCoursesByPageNumber()
    {
        List<Course> courses=getDummyCourseList();
        Mockito.when(this.courseRepository.findAll()).thenReturn(courses.stream().collect(Collectors.toList()));
        assertTrue(this.courseService.getCoursesByPageNumber(3,6).size()==6);
    }
    @Test
    public void test2ForGetCoursesByPageNumber()
    {
        List<Course> courses=getDummyCourseList();
        Mockito.when(this.courseRepository.findAll()).thenReturn(courses.stream().collect(Collectors.toList()));
        assertNull(this.courseService.getCoursesByPageNumber(5,10));
    }
    @Test
    public void test3ForGetCoursesByPageNumber()
    {
        List<Course> courses=getDummyCourseList();
        Mockito.when(this.courseRepository.findAll()).thenReturn(courses.stream().collect(Collectors.toList()));
        assertEquals(this.courseService.getCoursesByPageNumber(5,6).size(),1);
    }
    @Test
    public void test1ForGetCoursesByLowerOrderOfPrice()
    {
        List<Course> courses=getDummyCourseList();
        Mockito.when(this.courseRepository.findAll()).thenReturn(courses.stream().collect(Collectors.toList()));
        List<Course> coursesByIncOrder=this.courseService.getCoursesByLowerOrderOfPrice();
        for(int i=0;i<coursesByIncOrder.size();i++)
        {
          if(i<=coursesByIncOrder.size()-2) {
              assertTrue(coursesByIncOrder.get(i).getPrice()<=coursesByIncOrder.get(i+1).getPrice());
          }
        }
    }
    @Test
    public void test1ForGetCoursesByHigherOrderOfPrice()
    {
        List<Course> courses=getDummyCourseList();
        Mockito.when(this.courseRepository.findAll()).thenReturn(courses.stream().collect(Collectors.toList()));
        List<Course> coursesByIncOrder=this.courseService.getCoursesByHigherOrderOfPrice();
        for(int i=0;i<coursesByIncOrder.size();i++)
        {
            if(i<=coursesByIncOrder.size()-2) {
                assertTrue(coursesByIncOrder.get(i).getPrice()>=coursesByIncOrder.get(i+1).getPrice());
            }
        }
    }
    @Test
    public void testForGetCourseContainedKeyword()
    {
        List<Course> courses=getDummyCourseList();
        Mockito.when(this.courseRepository.findAll()).thenReturn(courses.stream().collect(Collectors.toList()));
        assertTrue(this.courseService.getAllCoursesContained("React 1001").size()==1);
    }
    @Test
    public void test2ForGetCourseContainedKeyword()
    {
        List<Course> courses=getDummyCourseList();
        Mockito.when(this.courseRepository.findAll()).thenReturn(courses.stream().collect(Collectors.toList()));
        assertTrue(this.courseService.getAllCoursesContained("React").size()==25);
    }
    @Test
    public void test3ForGetCourseContainedKeyword()
    {
        List<Course> courses=getDummyCourseList();
        Mockito.when(this.courseRepository.findAll()).thenReturn(courses.stream().collect(Collectors.toList()));
        assertTrue(this.courseService.getAllCoursesContained("saefdd").size()==0);
    }

}
