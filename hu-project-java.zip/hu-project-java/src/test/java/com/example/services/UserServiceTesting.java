package com.example.services;
import com.example.model.Course;
import com.example.model.Crud;
import com.example.model.User;
import com.example.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class UserServiceTesting
{
 @Mock
private UserRepository userRepository;
 @Autowired
 @InjectMocks
 UserService userService;
@BeforeEach
 public void setup()
{
 assertNotNull(userService);
}
public User dummyUser()
{
User user=new User();
user.setId(101);
user.setFirstName("Saksham");
user.setLastName("Solanki");
user.setDisplayName("Saksham Solanki");
user.setExperience("0-3 Years");
user.setAbout("Sasasaa");
return user;
}
@Test
 public void testForGetAllUsers()
{
    assertNotNull(userService);
    User user=dummyUser();
    Mockito.when(userRepository.findAll()).thenReturn(Stream.of(user).collect(Collectors.toList()));
    assertTrue(this.userService.getAllUsers().size()==1);
    assertEquals(userService.getAllUsers().get(0).getFirstName(),"Saksham");
}
    @Test
    public void testForGetAllUsers2()
    {
        Mockito.when(userRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(this.userService.getAllUsers().size()==0);
    }

@Test
    public void testForAddUser1()
   {
    User user=dummyUser();
    Mockito.when(userRepository.save(user)).thenReturn(user);
    assertEquals(true,userService.addUser(user));
   }
    @Test
    public void testForAddUser2()
    {
        User user=dummyUser();
        Mockito.when(userRepository.findAll()).thenReturn(Stream.of(user).collect(Collectors.toList()));
        assertEquals(false,userService.addUser(user));
    }

    @Test
    public void testForUpdateUser1()
    {
        User user=dummyUser();
        Mockito.when(userRepository.findAll()).thenReturn(Stream.of(user).collect(Collectors.toList()));
        assertTrue(userService.updateUser(user)==true);
    }

    @Test
    public void testForUpdateUser2()
   {
    User user=dummyUser();
    Mockito.when(userRepository.save(user)).thenReturn(user);
    assertTrue(userService.updateUser(user)==false);
   }
   @Test
    public void testGetUserById1()
   {
     User user=new User();
     user.setId(101);
    Mockito.when(userRepository.findAll()).thenReturn(Stream.of(user).collect(Collectors.toList()));
    assertTrue(userService.getUserById(user.getId()).getId()==user.getId());
   }
   @Test
   public void testForUserId3()
   {
       Mockito.when(userRepository.findAll()).thenReturn(new ArrayList<>());
       assertNull(userService.getUserById(1091));

   }
   @Test
   public void testGetUserById2()
   {
       User user=new User();
       user.setId(101);
       Mockito.when(userRepository.findAll()).thenReturn(new ArrayList<>());
       assertNull(userService.getUserById(user.getId()));
   }
    @Test
    public void testGetCoursesAllotedToUser1()
   {
       User user=dummyUser();
       List<Crud> cruds=new ArrayList<>();
       List<Course> courses=new ArrayList<>();
       Course course=new Course();
       course.setId(1001);
       course.setTitle("React");
       courses.add(course);
       Crud c=new Crud();
       c.setId(101);
       c.setCourses(courses);
       cruds.add(c);
       Mockito.when(userRepository.findAll()).thenReturn(Stream.of(user).collect(Collectors.toList()));
       assertTrue(userService.getCoursesAllotedToUser(101,cruds).size()==1);
   }
    @Test
    public void testGetCoursesAllotedToUser2()
    {
        User user=dummyUser();
        List<Crud> cruds=new ArrayList<>(); //empty list
        Mockito.when(userRepository.findAll()).thenReturn(Stream.of(user).collect(Collectors.toList()));
        assertFalse(userService.getCoursesAllotedToUser(101,cruds).size()==1);
    }
    @Test
    public void testGetCoursesAllotedToUser3()
    {
        List<Crud> cruds=new ArrayList<>();
        List<Course> courses=new ArrayList<>();
        Course course=new Course();
        course.setId(1001);
        course.setTitle("React");
        courses.add(course);
        Crud c=new Crud();
        c.setId(101);
        c.setCourses(courses);
        cruds.add(c);
        Mockito.when(userRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(userService.getCoursesAllotedToUser(101,cruds).size()==0);
    }

}
