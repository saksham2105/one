package com.example.services;
import com.example.model.ReviewAndRating;
import com.example.repository.ReviewAndRatingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ReviewAndRatingServiceTesting
{
 @Mock
 private ReviewAndRatingRepository reviewAndRatingRepository;
 @Autowired
 @InjectMocks
 private ReviewAndRatingService reviewAndRatingService;
 @BeforeEach
 public void init()
 {
  assertNotNull(reviewAndRatingRepository);
  assertNotNull(reviewAndRatingService);
 }
 public ReviewAndRating getDummyReviewAndRating()
 {
  ReviewAndRating reviewAndRating=new ReviewAndRating();
  reviewAndRating.setId("101_1002");
  reviewAndRating.setRating(4.3);
  reviewAndRating.setReviews(new ArrayList<>(Arrays.asList("Good","Better","Worst")));
  return reviewAndRating;
 }
 public List<ReviewAndRating> getDummyListOfReviewAndRating()
 {
  List<ReviewAndRating> reviewAndRatings=new ArrayList<>();
     ReviewAndRating reviewAndRating=new ReviewAndRating();
     reviewAndRating.setId("101_1002");
     reviewAndRating.setRating(4.3);
     reviewAndRating.setReviews(new ArrayList<>(Arrays.asList("Good","Better","Worst")));
     reviewAndRatings.add(reviewAndRating);
     reviewAndRating=new ReviewAndRating();
     reviewAndRating.setId("105_1002");
     reviewAndRating.setRating(3.2);
     reviewAndRating.setReviews(new ArrayList<>(Arrays.asList("Good","Better","Worst")));
     reviewAndRatings.add(reviewAndRating);
  return reviewAndRatings;
 }
 @Test
 public void test1ForGetAllRatingsAndReviews()
 {
  ReviewAndRating reviewAndRating=getDummyReviewAndRating();
  Mockito.when(this.reviewAndRatingRepository.findAll()).thenReturn(Stream.of(reviewAndRating).collect(Collectors.toList()));
  assertTrue(this.reviewAndRatingService.getAllRatingsAndReviews().size()==1);
 }
 @Test()
 public void test2ForGetAllRatingsAndReviews()
 {
        ReviewAndRating reviewAndRating=getDummyReviewAndRating();
        Mockito.when(this.reviewAndRatingRepository.findAll()).thenReturn(null);
        Mockito.when(this.reviewAndRatingRepository.findAll()).thenThrow(NullPointerException.class);
 }
    @Test()
    public void test3ForGetAllRatingsAndReviews()
    {
        ReviewAndRating reviewAndRating=getDummyReviewAndRating();
        Mockito.when(this.reviewAndRatingRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(this.reviewAndRatingService.getAllRatingsAndReviews().size()==0);
    }
    @Test
    public void test1ForGetFeedbackForCourse()
    {
        ReviewAndRating reviewAndRating=getDummyReviewAndRating();
        Mockito.when(this.reviewAndRatingRepository.findAll()).thenReturn(Stream.of(reviewAndRating).collect(Collectors.toList()));
        assertTrue(this.reviewAndRatingService.getFeedbackForCourse(1002).size()==1);
    }
    @Test
    public void test2ForGetFeedbackForCourse()
    {
        ReviewAndRating reviewAndRating=getDummyReviewAndRating();
        Mockito.when(this.reviewAndRatingRepository.findAll()).thenReturn(Stream.of(reviewAndRating).collect(Collectors.toList()));
        assertTrue(this.reviewAndRatingService.getFeedbackForCourse(1001).size()==0);
    }
    @Test
    public void test3ForGetFeedbackForCourse()
    {
        ReviewAndRating reviewAndRating=getDummyReviewAndRating();
        Mockito.when(this.reviewAndRatingRepository.findAll()).thenReturn(new ArrayList<>());
        assertTrue(this.reviewAndRatingService.getFeedbackForCourse(1002).size()==0);
    }
    @Test
    public void test4ForGetFeedbackForCourse()
    {
        List<ReviewAndRating> reviewAndRatings=getDummyListOfReviewAndRating();
        Mockito.when(this.reviewAndRatingRepository.findAll()).thenReturn(reviewAndRatings);
        assertTrue(this.reviewAndRatingService.getFeedbackForCourse(1002).size()==2);
    }
    @Test
    public void test1ForAddToRatingAndReviews()
    {
        ReviewAndRating reviewAndRating=getDummyReviewAndRating();
        Mockito.when(this.reviewAndRatingRepository.save(reviewAndRating)).thenReturn(reviewAndRating);
        assertTrue(this.reviewAndRatingService.addToRatingAndReviews(101,1002,4.2,reviewAndRating.getReviews()));
    }

}
