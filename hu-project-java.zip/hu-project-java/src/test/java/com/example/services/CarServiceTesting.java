package com.example.services;

import com.example.model.Car;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class CarServiceTesting
{
    @Autowired
     CarService carService;
    List<Car> audiCars=new ArrayList<>();
    List<Car> bmwCars=new ArrayList<>();
    public static void populateData(List<Car> aCars , List<Car> bCars)
    {

        try {
            Scanner sc;
            sc = new Scanner(new File("./src/main/java/com/example/assignment1/audi.csv"));
            sc.nextLine();
            Car car;
            //populating cars array ny fetching data from csv file
            while (sc.hasNext()) {
                String[] line = sc.nextLine().split(",");
                car = new Car();
                car.setId(UUID.randomUUID().toString()); // generating random unique id
                car.setModel(line[0]);
                car.setYear(Integer.parseInt(line[1]));
                car.setPrice(Long.parseLong(line[2]));
                car.setTransmission(line[3]);
                car.setMileage(Long.parseLong(line[4]));
                car.setFuelType(line[5]);
                car.setTax(Integer.parseInt(line[6]));
                car.setMpg(Double.parseDouble(line[7]));
                car.setEngineSize(Double.parseDouble(line[8]));
                aCars.add(car);
            }
            sc = new Scanner(new File("./src/main/java/com/example/assignment1/bmw.csv"));
            sc.nextLine();
            while (sc.hasNext()) {
                String[] line = sc.nextLine().split(",");
                car = new Car();
                car.setId(UUID.randomUUID().toString()); // generating random unique id
                car.setModel(line[0]);
                car.setYear(Integer.parseInt(line[1]));
                car.setPrice(Long.parseLong(line[2]));
                car.setTransmission(line[3]);
                car.setMileage(Long.parseLong(line[4]));
                car.setFuelType(line[5]);
                car.setTax(Integer.parseInt(line[6]));
                car.setMpg(Double.parseDouble(line[7]));
                car.setEngineSize(Double.parseDouble(line[8]));
                bCars.add(car);

            }
            sc.close();  //closes the scanner
        }catch (Exception e)
        {
            System.out.println(e);
        }

    }
    @BeforeEach
    public void beforeSetup()
    {
        carService=new CarService();
        populateData(audiCars,bmwCars);
    }
    @Test
    public void testForDataListPopulation()
    {
        boolean l1=this.audiCars.size()>0;
        boolean l2=this.bmwCars.size()>0;
        assertTrue(l1);
        assertTrue(l2);
    }
    @Test
    public void testForGetNewestCarWithLowestPriceTest()
    {
        Car c=carService.getNewestCarWithLowestPrice(audiCars,bmwCars);
        assertEquals(c.getModel()," 1 Series");
        assertEquals(c.getFuelType(),"Petrol");
        assertEquals(c.getTransmission(),"Semi-Auto");
        assertEquals(c.getPrice(),11995);
        assertEquals(c.getEngineSize(),2);
        assertEquals(c.getMileage(),10);
        assertEquals(c.getMpg(),34.5);
        assertEquals(c.getTax(),150);
        assertEquals(c.getYear(),2020);
    }
    @Test
    public void testGetPetrolBmwWithAutoTransmissionAndHighestMileage()
    {
        Car c=carService.getPetrolBmwWithAutoTransmissionAndHighestMileage(bmwCars);
        assertEquals(c.getModel()," 3 Series");
        assertEquals(c.getFuelType(),"Petrol");
        assertEquals(c.getTransmission(),"Automatic");
        assertEquals(c.getPrice(),4250);
        assertEquals(c.getEngineSize(),3.0);
        assertEquals(c.getMileage(),141000);
        assertEquals(c.getMpg(),39.8);
        assertEquals(c.getTax(),235);
        assertEquals(c.getYear(),2008);
    }
    @Test
    public void testGetDieselAudiWithManualTranmissionAndHighestMileage()
    {
        Car c=carService.getDieselAudiWithManualTranmissionAndHighestMileage(audiCars);
        assertEquals(c.getModel()," A6");
        assertEquals(c.getFuelType(),"Diesel");
        assertEquals(c.getTransmission(),"Manual");
        assertEquals(c.getPrice(),2490);
        assertEquals(c.getEngineSize(),2.0);
        assertEquals(c.getMileage(),323000);
        assertEquals(c.getMpg(),44.1);
        assertEquals(c.getTax(),200);
        assertEquals(c.getYear(),2008);
    }
    @Test
    public void testForTopTenCheapestCarWith2LtrsOfEngine()
    {
        List<Car> cars=carService.topTenCheapestCarWith2LtrsOfEngine(audiCars,bmwCars);
        assertNotNull(cars);
        assertTrue(cars.size()==10);
        int i=0;
        for(Car c : cars)
        {
            if(i<=8)
            {
                assertTrue(cars.get(i).getPrice()<cars.get(i+1).getPrice());
            }
            assertEquals(c.getEngineSize(),2);
        }
    }

    @Test
    public void testForTop5ModelCarWithMileageAbove7000()
    {
        List<Car> cars=carService.top5ModelCarWithMileageAbove7000(audiCars,bmwCars);
        int i=0;

        assertTrue(cars.size()==5);
        for(Car c : cars)
        {
            if(i<=3)
            {
                assertFalse(cars.get(i).getPrice()<cars.get(i+1).getPrice());
            }
            assertTrue(c.getMileage()>7000);
            i++;
        }
    }
    @Test
    public void testForGetTop10PetrolCarsWithTaxAbove200()
    {
        List<Car> cars=carService.getTop10PetrolCarsWithTaxAbove200(audiCars,bmwCars);
        assertEquals(cars.size(),10);
        for(Car c : cars)
        {
            assertTrue(c.getTax()>200 && c.getFuelType().equals("Petrol"));
        }
    }
    @Test
    public void testForTop3BmwLatestModelOfTypAutoAndPrixeBetweeen80kTo1Lakh()
    {
        List<Car> cars=carService.top3BmwLatestModelOfTypAuto(bmwCars);
        assertEquals(cars.size(),1);
        assertTrue(cars.get(0).getPrice()>80000 && cars.get(0).getPrice()<100000 && cars.get(0).getTransmission().equals("Automatic"));
    }

    @Test
    public void testForTop5SemiAutoAudisWithMpgGreaterThan60()
    {
        List<Car> cars=carService.top5SemiAutoAudisWithMpgGreaterThan60(audiCars);
        assertTrue(cars.size()==5);
        int i=0;
        for(Car c : cars)
        {
            if(i<=3)
            {
                assertFalse(cars.get(i).getPrice()<cars.get(i+1).getPrice());
            }
            assertTrue(c.getTransmission().equals("Semi-Auto") && c.getMileage()>60);
            i++;
        }
    }
    @Test
    public void testForGetCarWithManualTranmissionWithHighestPrice()
    {
        Car car=carService.getCarWithManualTranmissionWithHighestPrice(audiCars,bmwCars);
        assertEquals(car.getModel()," R8");
        assertEquals(car.getYear(),2013);
        assertTrue(car.getTransmission().equals("Manual"));
        assertTrue(car.getPrice()==47995);

    }



}
